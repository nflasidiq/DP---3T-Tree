#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include "header.h"

#define RED   "\x1B[31m"
#define GREEN "\x1B[32m"
#define RESET "\x1B[0m"

int main() {
	Session session;
    int choice;

    while (true) {
        printf("\n=== Menu ===\n");
        printf("1. Login\n");
        printf("2. Register\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                loginAllUser(&session);
            case 2:
                printf("=== Register ===\n");
                printf("1. Register sebagai pengguna biasa\n");
                printf("2. Register sebagai admin\n");
                printf("Enter your choice: ");
                int registerChoice;
                scanf("%d", &registerChoice);

                if (registerChoice == 1) {
                    registerUser();
                } else if (registerChoice == 2) {
                    registerAdmin();
                }
                break;
            case 3:
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}
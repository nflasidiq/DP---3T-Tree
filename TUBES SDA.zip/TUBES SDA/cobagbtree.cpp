#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#define RED   "\x1B[31m"
#define GREEN "\x1B[32m"
#define RESET "\x1B[0m"

typedef struct dataUser *address;
typedef struct dataUser {
    char username[20];
    char password[20];
    int id;
    address fs, nb, pr;
} User;

bool isFileExist(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file != NULL) {
        fclose(file);
        return true;
    }
    return false;
}

bool isUsernameUsed(const char *username) {
    char filename[20];
    sprintf(filename, "%s.txt", username);
    FILE *filePointer = fopen(filename, "r");
    if (filePointer == NULL) {
        return false; // File tidak ditemukan, username belum digunakan
    } else {
        fclose(filePointer);
        return true; // File ditemukan, username sudah digunakan
    }
}

bool isIDUsed(int id, const char *username) {
    char filename[20];
    sprintf(filename, "%s.txt", username);
    FILE *filePointer = fopen(filename, "r");
    if (filePointer == NULL) {
        return false; // File tidak ditemukan, ID belum digunakan
    } else {
        int existingID;
        fscanf(filePointer, "%d", &existingID); // Membaca ID yang ada di file
        fclose(filePointer);
        return existingID == id; // Mengembalikan true jika ID sudah digunakan
    }
}

int generateID() {
    return rand() % 100 + 0;
}

int generateUniqueID(User newUser) {
    int id;
    do {
        id = generateID();
    } while (isIDUsed(id, newUser.username));
    return id;
}

// Fungsi untuk membuat file .txt untuk pengguna baru
void createUserFile(User newUser) {
    FILE *filePointer;
    char filename[20];
	char filename2[20];
	
    strcpy(filename, newUser.username);
    strcat(filename, ".txt"); //file agar.txt

    // Membuka file dengan mode "w" (menulis)
    filePointer = fopen(filename, "w");

    // Memeriksa apakah file berhasil dibuka
    if (filePointer == NULL) {
        printf("Gagal membuat file.\n");
    } else {
        // Menulis informasi pengguna ke dalam file
        fprintf(filePointer, "%d ", newUser.id);
        fprintf(filePointer, "%s ", newUser.username);
        fprintf(filePointer, "%s", newUser.password);
        printf("File %s berhasil dibuat untuk pengguna baru.\n", newUser.username);
        fclose(filePointer);
    }
    
	// Membuat nama file kedua sebagai "AllUser.txt"
	strcpy(filename2, "AllUser.txt");
	
	// Membuka file kedua dengan mode "a" (append)
	filePointer = fopen(filename2, "a");
	
	// Memeriksa apakah file berhasil dibuka
	if (filePointer == NULL) {
	    printf("Gagal membuat file.\n");
	} else {
	    // Menulis informasi pengguna ke dalam file kedua
	    fprintf(filePointer, "%d ", newUser.id);
	    fprintf(filePointer, "%s ", newUser.username);
	    fprintf(filePointer, "%s\n", newUser.password); // tambahkan newline untuk pemisah antar pengguna
//	    printf("File %s berhasil dibuat untuk pengguna baru.\n", filename2);
	    fclose(filePointer);
	}

}

int main() {
    User newUser;
    srand(time(0));

    // Meminta pengguna untuk memasukkan nama pengguna
    printf("Masukkan nama pengguna: ");
    scanf("%s", newUser.username);
    
    while (isUsernameUsed(newUser.username)) {
    	system("cls");
        printf("Username sudah digunakan, masukkan username lain: ");
        scanf("%s", newUser.username);
    }
    
    printf("Masukkan password: ");
    scanf("%s", newUser.password);

    newUser.id = generateUniqueID(newUser);

    // Memanggil fungsi untuk membuat file .txt untuk pengguna baru
    createUserFile(newUser);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#define RED   "\x1B[31m"
#define GREEN "\x1B[32m"
#define RESET "\x1B[0m"

int main() {
    int pilihan;

    do {
        printf("Menu:\n");
        printf("1. Melakukan kontak\n");
        printf("2. Lihat Status\n");
        printf("3. Beranda Terinfeksi\n");
		printf("4. Laporkan Terinfeksi\n");
        printf("5. Keluar\n");
        printf("Pilih menu: ");
        scanf("%d", &pilihan);

        switch(pilihan) {
            case 1:
                printf("Anda memilih Melakukan kontak.\n");
                sleep(2);
                system("cls");
                // Isi dengan logika registrasi
                break;
            case 2:
                printf("Anda memilih Lihat Status.\n");
                sleep(2);
                system("cls");
                // Isi dengan logika lihat status
                break;
            case 3:
                printf("Anda memilih Beranda Terinfeksi.\n");
            	sleep(2);
                system("cls");
                break;
            case 4:
                printf("Anda memilih Laporkan Terinfeksi.\n");
            	sleep(2);
                system("cls");
                break;
            case 5:
                printf("Anda memilih Keluar. Terima kasih!\n");
                break;
            default:
                printf("Pilihan tidak valid. Silakan pilih lagi.\n");
                system("cls");
        }
    } while(pilihan != 5);

    return 0;
}
